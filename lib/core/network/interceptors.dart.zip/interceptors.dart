import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:jarpay/core/config/navigation_service.dart';
import 'package:jarpay/core/storage/secure_storage_service.dart';

class AuthInterceptor extends Interceptor {
  final Dio _dio;

  static bool _isRefreshing = false;
  static final List<Completer<void>> _refreshQueue = [];

  AuthInterceptor(this._dio);

  @override
  void onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    try {
      debugPrint('📤 REQUEST: ${options.method} ${options.path}');

      if (_isAuthEndpoint(options.path)) {
        debugPrint('   ↳ ⏭️ Skipping token (auth endpoint)');
        return handler.next(options);
      }

      final token = await SecureStorageService.getToken();

      if (token != null && token.isNotEmpty) {
        options.headers['Authorization'] = 'Bearer ${token.trim()}';
        debugPrint('   ↳ ✅ Token added (${token.length} chars)');
      } else {
        debugPrint('   ↳ ⚠️ No token available');
      }

      return handler.next(options);
    } catch (e) {
      debugPrint('   ↳ ❌ Error in onRequest: $e');
      return handler.next(options);
    }
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    if (_isBackendTokenErrorResponse(response)) {
      debugPrint('🚨 BACKEND TOKEN ERROR DETECTED IN onResponse');
      return handler.reject(
        DioException(
          requestOptions: response.requestOptions,
          response: response,
          type: DioExceptionType.badResponse,
          error: response.data["error"],
        ),
      );
    }

    handler.next(response);
  }

  bool _isBackendTokenErrorResponse(Response response) {
    if (response.data is! Map) return false;
    final error = response.data["error"]?.toString().toLowerCase() ?? "";
    return error.contains("token") &&
        (error.contains("invalid") || error.contains("expired"));
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    final statusCode = err.response?.statusCode;
    final isBackendTokenError = _isBackendInvalidToken(err);

    debugPrint('   ↳ Is 401? ${statusCode == 401}');
    debugPrint('   ↳ Is backend token error? $isBackendTokenError');

    if (statusCode == 401 || isBackendTokenError) {
      debugPrint('   ↳ 🔓 TOKEN ERROR CONFIRMED!');
      await SecureStorageService.clearTokens();
      rootNavigatorKey.currentState?.pushNamedAndRemoveUntil(
        '/login',
        (route) => false,
      );

      // Skip refresh for refresh endpoint itself
      // if (err.requestOptions.path.contains('/refresh')) {
      //   debugPrint('   ↳ ❌ Refresh endpoint itself failed');
      //   debugPrint('   ↳ 🧹 Clearing all tokens...');
      //   await SecureStorageService.clearTokens();
      //   debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      //   return handler.next(err);
      // }

      // try {
      //   // Start refresh process
      //   _isRefreshing = true;
      //   debugPrint('   ↳ 🔄 STARTING TOKEN REFRESH...');

      //   await _refreshToken();

      //   _completeWaitingRequests();
      //   debugPrint('   ↳ ✅ TOKEN REFRESH SUCCESSFUL!');

      //   return await _retryRequest(err, handler);
      // } catch (e) {
      //   debugPrint('   ↳ ❌ TOKEN REFRESH FAILED: $e');
      //   debugPrint('   ↳ 🧹 Clearing all tokens...');

      //   // await SecureStorageService.clearTokens();
      //   _completeWaitingRequests(isError: true);

      //   debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      //   return handler.next(err);
      // } finally {
      //   _isRefreshing = false;
      // }
    }

    debugPrint('   ↳ Not a token error, passing through...');
    debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    return handler.next(err);
  }

  // Future<void> _refreshToken() async {
  //   final refreshToken = await SecureStorageService.getRefreshToken();

  //   debugPrint('   ↳ 📞 Calling refresh API: /user/refresh');
  //   debugPrint('   ↳ Refresh token length: ${refreshToken?.length}');

  //   final refreshResponse = await _dio.post(
  //     "/user/refresh",
  //     data: {"refreshToken": refreshToken},
  //     options: Options(headers: {'Content-Type': 'application/json'}),
  //   );
  //   debugPrint('   ↳ 📥 Refresh api response --------: $refreshResponse');

  //   debugPrint('   ↳ 📥 Refresh response: ${refreshResponse.statusCode}');
  //   debugPrint('   ↳ Response data: ${refreshResponse.data}');

  //   final responseData = refreshResponse.data;
  //   final newToken = responseData["accessToken"] ?? responseData["token"];
  //   final newRefreshToken = responseData["refreshToken"] ?? refreshToken;

  //   if (newToken == null) {
  //     throw Exception('No access token in refresh response');
  //   }

  //   await SecureStorageService.saveToken(newToken);
  //   await SecureStorageService.saveRefreshToken(newRefreshToken);

  //   debugPrint('   ↳ 💾 New tokens saved');
  //   debugPrint('   ↳ New access token length: ${newToken.length}');
  // }

  Future<void> _retryRequest(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    try {
      debugPrint('   ↳ 🔄 Retrying original request...');

      final newToken = await SecureStorageService.getToken();

      if (newToken == null) {
        throw Exception('No token after refresh');
      }

      final requestOptions = err.requestOptions;
      requestOptions.headers['Authorization'] = 'Bearer $newToken';

      final response = await _dio.fetch(requestOptions);

      debugPrint('   ↳ ✅ RETRY SUCCESSFUL!');
      debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      return handler.resolve(response);
    } catch (e) {
      debugPrint('   ↳ ❌ Retry failed: $e');
      debugPrint('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      return handler.next(err);
    }
  }

  Future<void> _waitForRefresh() async {
    final completer = Completer<void>();
    _refreshQueue.add(completer);
    return completer.future;
  }

  void _completeWaitingRequests({bool isError = false}) {
    for (var completer in _refreshQueue) {
      if (!completer.isCompleted) {
        if (isError) {
          completer.completeError(Exception('Token refresh failed'));
        } else {
          completer.complete();
        }
      }
    }
    _refreshQueue.clear();
  }

  bool _isAuthEndpoint(String path) {
    return path.contains('/login') ||
        path.contains('/register') ||
        path.contains('/refresh') ||
        path.contains('/forgot-password');
  }

  bool _isBackendInvalidToken(DioException err) {
    try {
      final data = err.response?.data;
      if (data is Map<String, dynamic>) {
        final error = data["error"]?.toString();
        final tokenErrorMessages = [
          "Invalid token",
          "Token expired",
          "Authentication failed. Token is invalid or malformed.",
          "Authentication token missing",
        ];

        return data["status"] == 0 && tokenErrorMessages.contains(error);
      }
    } catch (_) {
      return false;
    }
    return false;
  }
}

/*
═══════════════════════════════════════════════════════════════════════
🔍 WHAT TO LOOK FOR IN THE LOGS:
═══════════════════════════════════════════════════════════════════════

When you run your app, you should see:

1. ━━━ REQUEST section
2. ━━━ RESPONSE section with "🚨 BACKEND TOKEN ERROR"
3. ━━━ ERROR INTERCEPTOR TRIGGERED section
4. Either:
   ✅ "🔄 STARTING TOKEN REFRESH" → Success
   OR
   ❌ "NO REFRESH TOKEN FOUND" → Need to re-login

If you see "NO REFRESH TOKEN FOUND", do this:

1. Clear app data or uninstall app
2. Login again
3. Make sure your login code saves BOTH tokens:
   
   await SecureStorageService.saveToken(accessToken);
   await SecureStorageService.saveRefreshToken(refreshToken);

4. Try the API call again

═══════════════════════════════════════════════════════════════════════
*/
